<?php
/** This file for running bot
*/
require_once('veeu_func.php');
dbg_menu();
?>