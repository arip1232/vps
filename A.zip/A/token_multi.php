<?php
/**This is Config File
* this config for multiple account
* this config only work for watching videos
*/
$token1='xxxxxxxxxxxxx';
$token2='xxxxxxxxxxxxx';
$token3='xxxxxxxxxxxxx';
$token4='xxxxxxxxxxxxx';
$token5='xxxxxxxxxxxxx';
?>